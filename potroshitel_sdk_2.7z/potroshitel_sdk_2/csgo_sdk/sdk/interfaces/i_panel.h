#pragma once

class i_panel {
public:
	VFUNC(get_name(uint32_t id), 36, const char*(__thiscall*)(void*, uint32_t), id)
};
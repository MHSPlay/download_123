#pragma once
#include "common_includes.h"
#include "sdk/interfaces.h"
#include "hacks/hacks.h"
#include "local_player/local_player.h"
#include "utils/singleton.h"

namespace globals {

	inline int m_width, m_height = {};



}